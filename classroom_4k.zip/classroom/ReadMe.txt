
Scene organization :

These scene was created for testing cycles engine in interior scene with lots of light sources and bounced lights.
These scene was organised for easily re-use all assets in other project.

The main file "classroom.blend" countain 3 scenes :

_mainScene : On top layers there are meshes, on bottom layers there are light sources. I've been using group intance for 
assets. Venitian blinds are rigged for rotating, raising or lowering it
Compositing was done in these scene.
For reusing assets you need to put the assets folder beside your blend file and put the baseTextures in your textures folder,
then go to File/link/asset/assetName/assetName.blend/group/assetName


_dustParticules : these scene contain dust particles suspended in the air. (the particule system was rendered with blender internal)


_volumeLight : these scene countain volumes light passing throw the window and one for the blackboard lamp.(rendered with blender internal)




for rendering images I've been using an online renderFarm called qarnot computing


Christophe SEUX :

christopheseux@free.fr
